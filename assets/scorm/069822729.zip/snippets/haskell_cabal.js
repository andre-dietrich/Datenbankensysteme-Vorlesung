ace.require(["ace/snippets/haskell_cabal"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
