ace.require(["ace/snippets/puppet"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
