ace.require(["ace/snippets/nasal"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
