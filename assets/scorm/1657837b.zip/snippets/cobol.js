ace.require(["ace/snippets/cobol"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
