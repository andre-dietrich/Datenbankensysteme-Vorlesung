ace.require(["ace/snippets/mips"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
