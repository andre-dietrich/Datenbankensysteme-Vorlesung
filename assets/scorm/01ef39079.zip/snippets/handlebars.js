ace.require(["ace/snippets/handlebars"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
