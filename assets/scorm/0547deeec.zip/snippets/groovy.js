ace.require(["ace/snippets/groovy"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
