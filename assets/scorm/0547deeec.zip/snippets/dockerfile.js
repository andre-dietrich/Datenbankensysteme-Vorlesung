ace.require(["ace/snippets/dockerfile"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
