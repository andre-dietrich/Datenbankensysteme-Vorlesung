ace.require(["ace/snippets/pascal"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
