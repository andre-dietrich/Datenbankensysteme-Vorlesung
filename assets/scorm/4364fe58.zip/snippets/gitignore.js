ace.require(["ace/snippets/gitignore"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
