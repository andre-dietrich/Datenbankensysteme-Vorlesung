ace.require(["ace/snippets/rdoc"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
